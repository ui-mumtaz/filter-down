const star = n => {
    let res = '';
    for(let i=0; i<n; i++) {
        for(j=n; j>=i; j--) {
            res += '*'
        }
        res = res + '\n'
    }
    return res;
    
}
/* const star = n => {
    let res = '';
    for(let i=0; i<n; i++) {
        for(j=0; j<i; j++) {
            res += '*'
        }
        res = res + '\n'
    }
    return res;
    
} */

console.log(star(5));


const arr = [4, 3, 5, 1, 6, 2];

const bubbleSort = array => {
    console.log(array);

    for (let i = arr.length; i > 0; i--) {
        for (let j = 0; j < i - 1; j++) {
            if (array[j] > array[j + 1]) {
                [array[j], array[j + 1]] = [array[j + 1], array[j]]
            }
        }
    }
    return array;
}

console.log(bubbleSort(arr));