// binary search alogr
// find the index of given no in an array 

const arr = [5,6,7,8,9];

const binarySearch = (array, element) => {
    let startingIndex = 0;
    let endingIndex = array.length-1;
    let middleIndex = Math.floor((startingIndex + endingIndex)/2)
    //console.log('middleIndex : ', middleIndex, 'startingIndex : ', startingIndex, 'endingIndex : ', endingIndex);
    //console.log(startingIndex <= endingIndex);
    
    while(array[middleIndex] !== element && startingIndex <= endingIndex) {
        if(array[middleIndex] > element) {
            endingIndex = middleIndex -1;
        } else {
            startingIndex = middleIndex + 1;
        }
        middleIndex = Math.floor((startingIndex + endingIndex)/2)
    }
    return array[middleIndex] == element ? middleIndex : -1;
}

console.log(binarySearch(arr, 7));





const users = [
    {username: "Sami", email: "sami@abc.com"},
    {username: "Wasi", email: "wasi@abc.com"},
    {username: "Safi", email: "safi@abc.com"},
    {username: "Mumtaz", email: "mum@abc.com"},
    {username: "Ahmad", email: "ahmd@abc.com"},
    {username: "Saba", email: "sab@abc.com"}
]

const isUserTaken = (arr, val) => {
    for (let item of arr) {
        if (item['username'] == val) {
            return true
        }
    }
    return false
}

// console.log(isUserTaken(users, 'Sami'));





