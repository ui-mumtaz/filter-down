const arr = [4, 3, 2, 5, 4, 4, 4, 1, 6, 2, 4];


const custSort = (item) => {
    console.log(item);
    
   let result =  item.reduce((acc, val)=> {
        if(!acc[val]) acc[val] = 0;
        acc[val]++
        return acc;
    },{})

    var minValue = 0;
        let output = '';

    for(let i in result) {
       
        
        if(result[i] > minValue) {
           minValue = result[i];
           output = i;
        }

    }
    return {
        item: output,
        noOfRepeat: minValue
    }

   // return result
    
}
console.log(custSort(arr));