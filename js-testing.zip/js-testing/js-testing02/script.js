function add(...args) {
  const result = args.reduce((ac, value) => ac + value);
  return sum = (...ar) => ar.length ? add(...args, ...ar) : result;
}

console.log(add(3, 5, 1, 2)(3)())

/* function fixCurry(fn, totalArgs) {
  totalArgs = totalArgs || fn.length
  return function recursor() {
    return arguments.length < totalArgs ?
      recursor.bind(this, ...arguments) :
      fn.call(this, ...arguments);
  }
}


var add = fixCurry((a, b, c) => a + b + c); //fn = summation function
console.log(add(1, 2, 3)) // output: 6
console.log(add(1)(2, 3)) // output: 6
console.log(add(1)(3)(2)) // output: 6
console.log(add(1)(3)) // output: 6
 */








/* const recur = a => {
  let temp = [0, 1];
  for (let i = temp.length; i <= a; i++) {
    temp[i] = temp[i - 2] + temp[i - 1]
  }
  return temp
}

console.log(recur(4)); */


/* const obj = [
  { id: 1, name: 'burger', price: 50 },
  { id: 2, name: 'pizza', price: 100 },
]

//const getName = (id) => (item) => item.find(it => it.id == id).name;

const curry = (fn) => {
  return (...args) => {
    if (args.length >= fn.length) {
      return fn.apply(null, args)
    }
    return fn.bind(null, ...args)
  }
}

const getName = curry((id, item) => item.find(it => it.id == id).name)
const getData = getName(2, obj);
const getData1 = getName(1)(obj);

console.log(getData, getData1);

 */



/* function Developer(name) {
  this.name = name;
  this.type = 'Developer'
}

function Tester(name) {
  this.name = name;
  this.type = 'Tester'
}

function EmployeeFactory() {
  this.create = (name, type) => {
    switch (type) {
      case 1:
        return new Developer(name)
      case 2:
        return new Tester(name)
    }
  }
}

function say() {
  console.log("Hi I am " + this.name + " and I am a " + this.type);
}

const employeeFactory = new EmployeeFactory();
let employees = [];

employees.push(employeeFactory.create("mumtaz", 1))
employees.push(employeeFactory.create("Ahmad", 2))

employees.forEach(res => say.call(res)) */