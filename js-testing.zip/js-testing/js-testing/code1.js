const getParisCount = (arr, sum) => {
    let count = 0;
    let pairs = [];
    for(let i=0; i<arr.length; i++){
        for(let j=i+1; j<arr.length; j++){
            if(arr[i] + arr[j] == sum) {
                count++
                pairs.push([arr[i], arr[j]])
            }
        }
    }
    return {
        count, 
        pairs
    }    
    
}

const getMinMax = (arr) => {
    let min = arr[0];
    let max = arr[0];

    for (let i = 0; i < arr.length; i++) {
        if(max > arr[i]) {
            max = arr[i]
        }
        if(min < arr[i]) {
            min = arr[i]
        } 
    }
    return {
        max, min
    }
}

let aa = [1,2,3,4,5,6]
console.log(getParisCount(aa, 6));
console.log(getMinMax(aa));
