const reverseText = string => {
    let revStr = '';
    for (let str of string) {
        revStr = str + revStr
    }
    return revStr
}

//console.log(reverseText('welcome to the world'));

const reverseArrayInPlace = arr => {
    arr = arr.split(' ')
    for(let i =0; i<arr.length/2; i++) {
        let tempArr = arr[i];
        //console.log('tempArr ', tempArr);
       // console.log('tempArr ', arr[i]);
       secondLast = arr[arr.length - 2];

        arr[i] = arr[arr.length - 1 - i];
       // console.log('tempArr r ', arr[i]);

        arr[arr.length - 1 - i] = tempArr
    }
    arr = arr.join(' ')
    return {arr, secondLast};
}

//console.log(reverseArrayInPlace([1,2,3,4,5,6]));
console.log(reverseArrayInPlace('welcome to the world'));


const sum = a => b => b ? sum(a + b) : a;

//console.log(sum(2)(3)(4)());

const removeDup = string => {
    return string.filter((x, index) => string.indexOf(x) == index)
}

//console.log(removeDup([1,2,1,2,1,4]));

const getOccurance = string => {
    let occur = string.reduce((a, b) => {
        if (!a[b]) a[b] = 0;
        a[b] += 1;
        return a;
    }, {});

    let max = 0;
    let res = ''

    for (let txt in occur) {
        if (occur[txt] > max) {
            max = occur[txt]
            res = txt
        }
    }
    
    return {
        value: res,
        repeatingNumer: max
    }
}
//console.log(getOccurance([1, 2, 1, 2, 1, 4]));