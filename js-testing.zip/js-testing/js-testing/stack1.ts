class Stack1 {
    items;
    constructor(){
        this.items = [];
        console.log("stack is ready")
    }
    isEmpty(){
        if(this.items.length==0){
            return true;
        } else {
            return false;
        }
    }
    pushElement(ele){
        this.items.push(ele)
        console.log("Item pushed...")
    }

    display(){
        if(stack.isEmpty()){
            console.log("Stack is Emplty..")
        } else {
            console.log("Stack elements are ..");
            for(let i=this.items.length-1; i>=0; i--){
                console.log(this.items[i]);
            }
          } 
    }
}
var stack = new Stack1();
if(stack.isEmpty()){
    console.log("Stack is Emplty..")
} else {
    console.log("Stack has elements..")
}
stack.pushElement(10)
console.log("Stack is Emplty.. : ", stack.isEmpty())

stack.pushElement(20)
stack.pushElement(30)
stack.pushElement(40)
stack.pushElement(50)

stack.display()

