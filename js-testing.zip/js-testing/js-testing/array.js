function output(arr) {
    let result = []
    for (let i = 0; i < arr.length; i++) {
        let next = -1;
        for (let j = i + 1; j < arr.length; j++) {
            if (arr[i] < arr[j]) {
                next = arr[j];
                break;
            }
        }
        result.push(next);
    }
    return result
}

let arr = [5, 3, 2, 4, 8, 6, 1, 9];

console.log(output(arr));