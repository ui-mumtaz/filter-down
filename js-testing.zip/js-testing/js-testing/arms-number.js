const armstrong = (num) => {

    const toArray = num.toString().split('').map(Number);

    const newNum = toArray.map(a => {return a**3}).reduce((a, b) => a + b);

    if(newNum == num){
        console.log('This is an armstrong number');
    }else{
        console.log('This is not an armstrong number');

    }
}
//armstrong(153);


const armstrong2 = (num) => {
    const toArray = num.toString().split('').map(Number);
    //console.log(toArray)
    let len = toArray.length;
   // console.log(len)
    const newNum = toArray.map(a => a**len)
   // console.log(newNum)
    const arm = newNum.reduce((a,b)=> a+b)
  //  console.log(arm)


    return arm == num ? 'true' : 'false';
}
/* console.log('92727 is ', armstrong2(92727));
console.log('153 is ', armstrong2(153));
console.log('1634 is ', armstrong2(1634));
console.log('9 is ', armstrong2(9)); */

const starPrint = () => {
    let res = '';
    for(let i=0; i<10; i++){
        for(let j=0; j<i; j++) {
            res += '*';
          //  console.log(res);
            
        }
        res = res + '\n'
    }
    return res;
}

console.log(starPrint())


const findFactorialize = num => {
    let ans = 1;
    for(let i=2; i<=num; i++) {
      ans = ans * i;
    }
    return ans;
  }
  
  findFactorialize(5) //5x4x3x2x1




