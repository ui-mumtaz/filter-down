const computer = [
    {name: 'Apple', ram: '4GB'},
    {name: 'HP', ram: '8GB'},
    {name: 'HP', ram: '6GB'},
    {name: 'Dell', ram: '4GB'}
]

//let res = computer.some(x=> x.ram == '2GB')
let res = computer.map(({name})=> name).reduce((a, b) => ({ ...a, [b]: (a[b] || 0) + 1}), {})
let duplicates =  Object.keys(res).filter((a) => res[a] > 1)
console.log(res);
console.log(duplicates);
