// Find all the numbers from 1 to 10000 which summation of nth power of the digits
//153 = 1^3 + 5^3 + 3^3 where n = 3

const fab = n => {
    let numArr = n.toString().split('').map(Number);
    let summNum = numArr.map(x=> x**numArr.length).reduce((a,b)=> a+b);
    
    return (n == summNum) ? 
    (`input num ${n} == ${summNum} output numer : true`) : 
    (`input num ${n} !== ${summNum} output numer : false`)
  }
  console.log(fab(153));


const fabin = num => {
    let init = [0,1];
    for(let i=init.length; i<=num; i++) {
        init[i] = init[i-2] + init[i-1]
    }
    return init
}

console.log(fabin(8)); // [0,1,1,2,3,5,8]



function output (arr, target) {
    var result = [];
  
    for (var i = 0; i < arr.length; i++) {
      for (var j = i + 1; j < arr.length; j++) {
        if (arr[i] + arr[j] === target) {
          result.push(i);
          result.push(j);
        }
      }
    }
    return result;
  }
  //console.log(output([2,  11, 15, 7], 9)); // [ 0, 3 ]
  
  // q-2
  function find_triplets(arr) {
      let res = [];
      arr.sort((a,b)=> a-b);
     // console.log(arr);
  
      for(let i=0; i<arr.length-1; i++){
        for(let j=i+1; j<arr.length-1; j++) {
          for(let k = j + 1; k<arr.length; k++){
            if (arr[i] + arr[j] + arr[k] == 0) {
                      res.push([arr[i], arr[j], arr[k]])
                  }
          }
        }
      }
      return res;
    }
    
    //console.log(find_triplets([-1, 0, 1, 2, -1, -4]))
    //[ [ -1, -1, 2 ], [ -1, 0, 1 ], [ -1, 0, 1 ] ]