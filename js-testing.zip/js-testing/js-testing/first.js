/* function sum(...args){
          return args.reduce((a,b)=> a + b)
        } */

       /*  let sum = function (a) {
            return function (b) {
                if (b) {
                    return sum(a + b)
                }
                return a;
            }
        } */
       /*  let sum = a => b => b ? sum (a + b) : a; */
      /*  function sum (a) {
           return (b) => {
               return (c) => {
                   return a + b + c;
               }
           }
       }
        console.log(sum(2)(3)(6)) */

    /* let arr = [1,2,5,1,1,4,3,1,3];

    let output = arr.reduce((a,b)=> {
        if(!a[b]) {
            a[b] = 0
        }
        a[b]++;
        return a;
    }, {})


    
let myA = [1,2,1,5,3];

for(let i =0; i<myA.length; i++) {
  for(let j=0; j<(myA.length-i-1); j++) {
    if(myA[j] === myA[j+1]) {
      myA.splice(j, 1)
    }
  if(myA[j] > myA[j+1]) {
    let temp = myA[j];
    myA[j]=myA[j+1];
    myA[j+1]=temp
  }
  }
}

console.log(myA)


   //let output =  arr.filter((txt, index)=> arr.indexOf(txt) == index)
   console.log(output) */
   /* let arr1 = [1,2,5,1,1,4,3,1,3];
   let arr2 = [1,2,5];

   let out = arr2.every(arr => arr1.includes(arr));
   console.log(out) */

   /* let arr = [1,2,5,1,1,4,3,1,3]
   let max = arr[0];
   let min = arr[0];

   for(let i=0; i<arr.length; i++) {
       if(arr[i]>max) {
           max = arr[i]
       } else if (arr[i]<min){
           min = arr[i]
       }
   }

   console.log('max', max)
   console.log('Min : ', min) */

   var num = 4;
   function outer(){
       var num = 2;
       function inner(){
           num++;
           var num = 3;
           console.log(num)
       }
       inner()
   } 
   outer()