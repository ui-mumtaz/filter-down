//Find the Missing Number
//You are given a list of n - 1 integers and these integers are in the range of 1 to n.There are no duplicates in list.One of the integers is missing in the list.Write an efficient code to find the missing integer.

let num = [1, 2, 4, 6, 3, 7, 8];
const findMissingNo = num => {
    let n = num.length;
    let sum = num.reduce((a,b)=> a+b);

   return {
       inputNumber: num.sort((a,b)=> a-b),
       missingNumber: (n+1)*(n+2) / 2 - sum
   };
}

console.log(findMissingNo(num));


let array = [[13, 27, 18, 26], [4, 5, 1, 3], [32, 35, 37, 39], [1000, 1001, 857, 1]]
const largeNumber = string => {
    let list = [];
    for (let i = 0; i < string.length; i++) {
        let largeNumber = 0;
        for (let j = 0; j < string[i].length; j++) {
            if (largeNumber < string[i][j]) {
                largeNumber = string[i][j];
            }
        }
        list[i] = largeNumber;
    }
    return {
        inputNumber: array,
        largeNumberArr : list
    }
}

console.log(largeNumber(array));

const chunk = (arr, size) => {
    let chunked = [];
    for (let a of arr) {
        let last = chunked[chunked.length - 1];
        if (!last || last.length == size) {
            chunked.push([a])
        } else {
            last.push(a)
        }
    }
    return {
        inputArray: arr,
        chunked: chunked
    }
}

const chunk2 = (arr, size) => {
    const chunked = [];
    let index = 0;
    while(index < arr.length) {        
        chunked.push(arr.slice(index, index+size))
        index += size;
    }
    return {
        inputArray: arr,
        chunked: chunked
    }
}

console.log(chunk2([1,2,3,4], 2));
//console.log(chunk([1,2,3,4,5], 2));
//console.log(chunk([1,2,3,4,5,6,7,8], 3));

const pyramid = (n) => {
   /*  const midPoint = Math.floor((2 * n - 1) / 2)

    for(let i=0; i<n; i++) {
        let level = '';
        for(let c=0; c< (2*n)-1; c++) {
           if(midPoint - i <= c && midPoint + i >= c) {
               level += '#'
           } else {
               level += ' '
           }
            
        }
        console.log(level);
        
    } */

    let output = '';
    for(let i=0; i<n; i++) {
       for(let j =0; j<i; j++) {
          output += '*'
       }
       output += '\n'
    }
    return output

}
//console.log(pyramid(5));

const nums = [10, -12, 30, -1, -8, 0, 14, -33, 20];
const plusMinus = string => {
   let output = string.reduce((acc, elem)=> {
       return {
        plus:elem > 0 ? acc.plus + elem : acc.plus,
        minus:elem < 0 ? acc.minus + elem : acc.minus,
       }
    },{plus:0, minus:0})
    
 return output;
    
}
console.log(plusMinus(nums));



const fibonacci = string => {
    let res = [0, 1];
    ;
    for(var i=res.length; i<=string ; i++) {
       res[i] = res[i-2] + res[i-1];
    }
   return {
       out: res
   }; 
}
const fibonacci2 = string => {
    return string <= 1 ? string : fibonacci2(string - 1) + fibonacci2(string - 2);
   /*  if(string < 3) return 1;
    else {        
        return fibonacci2(string-1) + fibonacci2(string-2);
    } */
}


console.log(fibonacci(20)); 
console.log(fibonacci2(20)); 



