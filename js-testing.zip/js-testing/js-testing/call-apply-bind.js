//Call
function obj(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
}

function person(firstName, lastName, age) {
    obj.call(this, firstName, lastName)
    console.log(`My first name is ${this.firstName} and last name ${this.lastName}, age is ${age}`)
}

person('saba', 'naaz', 6);

function fullName() {
    return `My first name is ${this.firstName} and last name is ${this.lastName}`
}
console.log(fullName.call(obj('sabaa', 'nnnn')));
console.log(fullName.apply(obj('wasi', 'aaaahhhhh')));
//bind
let newOne = fullName.bind(obj('nnnnn', 'aaaa'));
console.log(newOne());

//simple execution
function init() {
    var firstName = "Saba Naz";

    function sayFirstName() {
        console.log(firstName);
    }
    sayFirstName()
}
init()

//clouser store current context
function init2() {
    var firstName = "Saba Naz";

    function sayFirstName() {
        console.log(firstName);
    }
    return sayFirstName;
}
var getValue = init2();
getValue()

// 2nd ex of closure
function addition(x) {
    return function (y) {
        return x + y;
    }
}
var add = addition(5);
console.log(add(5));
console.log(addition(4)(4));

//send ex

function Person(name, age) {
    this.name = name;
    this.age = age
}

function Student(name, age, grade) {
    Person.call(this, name, age);
    this.grade = grade;
}

let s1 = new Student('safi', 8, 'A')
let s2 = new Student('Saba', 5, 'A')

console.log(s1, s2);