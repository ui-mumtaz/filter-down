let arr = [2, 3, 7, 9, 11, 15, 19, 25];

const findPositionArr = (arr, inp) => {
    for(let i in arr) {
        if(arr[i] === inp) {
            return i;
        }
    }
}

console.log(findPositionArr(arr, 3));

let arr1 = [0,6,0,0,2,1,0,5]

let moveZeroToEnd = arr => {
    let arrB = [];
    let arrC = []
    for(let i in arr) {
        if(arr[i] !== 0) {
            arrB.push(arr[i])
        } else {
            arrC.push(arr[i])
        }
    }
    return [... arrB, ...arrC]
}

//console.log(moveZeroToEnd(arr1));

const firstNonRepeatingChar = str => {
    for(let i in str) {
        if(str.indexOf(str.charAt(i)) == str.lastIndexOf(str.charAt(i))) {
            return str.charAt(i);
            //break;
        }
    }
}

console.log(firstNonRepeatingChar('mumtazahmad'));

