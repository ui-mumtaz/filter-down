const findPermutations = string => {
    if(string.length < 2){
        return string;
    }

    let permutationsArray = [];
    for(let i=0; i<string.length; i++) {
        let char = string[i];
       // console.log('chr : ', char)

        let remainChar = string.slice(0, i) + string.slice(i+1, string.length);
        console.log('rr : ', remainChar)
        for(let txt of findPermutations(remainChar)) {
            permutationsArray.push(char + txt)
        }
        
      //  console.log(permutationsArray)
    }
    return permutationsArray;
}

console.log(findPermutations('ABC'))