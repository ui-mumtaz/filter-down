// 4*3*2

//const fab = n => n<=1 ? n : fab(n-1) * n
//const fab = n => n<=1 ? n : fab(n-2) + fab(n-1)
const fab = n => {
    let numArr = n.toString().split('').map(Number);
    let summNum = numArr.map(x=> x**numArr.length).reduce((a,b)=> a+b);
    
    return (n == summNum) ? 
    (`input num ${n} == ${summNum} output numer : true`) : 
    (`input num ${n} !== ${summNum} output numer : false`)
  }
  //console.log(fab(153));
  
  function statement(){
      let isValue = true;

      if(isValue){
          let inp = 'hellooo';
          console.log(inp)

      }

    //  console.log(inp)
  }

const removeDup = string => {
    return string.filter((x, index) => string.indexOf(x) == index)
}

const reverse = arr => {
  arr = arr.split('')
  for(let i=0; i<arr.length/2; i++) {
   let temp = arr[i];
   arr[i] = arr[arr.length-1-i];
   arr[arr.length-1-i] = temp;
}
return arr.join('')
}
  //start pattern
  function starPatter(){
      let output
      for(let i=0; i<5; i++){
          for(let j=1; j<=i; j++){
            output += j;
        }
        output +='\n';
      }
      return output;
  }
 //console.log( starPatter());
 const order = () => {
     let arr = [0,6,0,0,2,1,0,5];
     let min = []
     let max = []
     for(let i=0; i<arr.length; i++) {
        arr[i] !== 0 ?  max.push(arr[i]) : min.push(arr[i])
     }
     /* for(let i in arr) {
          arr[i] !== 0 ?  max.push(arr[i]) : min.push(arr[i])
     } */
    
     return [...max, ...min]
 }

 //console.log(order());


 let bruteForceTwoSum = (array, sum) => {
    let nums = []
        for(let x in array){
          for(let y in array){
            if (array[x] + array[y] === sum){
                nums.push([array[x], array[y]])
               }
            
            }
        }  	
     return nums
  }
let array = [2, 3, 4, 3, 6, 7]
let sum = 5
//console.log(bruteForceTwoSum(array, sum));


function find_triplets(arr) {
    let res = [];
    arr.sort((a,b)=> a-b);
   // console.log(arr);

    for(let i=0; i<arr.length-1; i++){
      for(let j=i+1; j<arr.length-1; j++) {
        for(let k = j + 1; k<arr.length; k++){
          if (arr[i] + arr[j] + arr[k] == 0) {
                    res.push([arr[i], arr[j], arr[k]])
                }
        }
      }
    }
    return res;
  }
  
  console.log(find_triplets([-1, 0, 1, 2, -1, -4]))