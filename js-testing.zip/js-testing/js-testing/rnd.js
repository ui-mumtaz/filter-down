/* 
let sum = a => b => b ? sum(a+b) : a;

console.log(sum(2)(3)(6)()); */

const arr = [1,2,3,2,1,4,1];

let obj = arr.reduce((a,e)=>{
    if(!a[e]) {
       a[e] = 0;
    } 
    a[e]++;
    return a;
}, {})

console.log(obj)


let char='';
let max=0;
let fin = [];
for(let x in obj){
  if(obj[x] > max){
    max = obj[x];
    char = x;
  }
}
console.log(max); //3