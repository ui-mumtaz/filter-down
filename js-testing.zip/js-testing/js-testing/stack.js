var Stack = function() {
    this.storage = [];
}

Stack.prototype.add = function(x) {
    this.storage.push(x);
}

Stack.prototype.remove = function() {
    return this.storage.pop();
}

Stack.prototype.getSize = function() {
    return this.storage.length;
}

var mapple = new Stack();
mapple.add("Saba");

console.log(mapple);