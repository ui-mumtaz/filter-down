// hElLoWoRlD

const changeCase = (txt) => {
  let newStr = txt.split('')
    .map((x, index) => index % 2 == 0 ? x.toLowerCase() : x.toUpperCase())
    .join('')
  return newStr;
}

console.log(changeCase('hElLo wOrLd, It iS So nIcE To bE AlIvE'));
