import { Component } from '@angular/core';
import { FilterPipeService } from './filter-pipe.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';
  name = 'Angular-search';
  dbFilter: any;
  config: any;

  constructor(private fs: FilterPipeService){
    this.config = {
      currentPage: 1,
      itemsPerPage: 2,
      totalItems: 0
    };
    this.fs.getCount.subscribe(x=> {
      console.log('cc: ', x);
      this.config.totalItems = x;
    })
  }
  //dbFilter: any = { groupName: '' };
  users =[
    {'full_name':'Mumtaz Ahmad','address':'South Delhi, New Delhi','interests':'playing guitar'},
    {'full_name':'Vipin Kumar','address':'East Delhi, New Delhi','interests':'playing cricket'},
    {'full_name':'Ravi Kumari','address':'West Delhi, New Delhi','interests':'singing'},
    {'full_name':'Vinita Kumari','address':'Central Delhi, New Delhi','interests':'dancing'}
  ]

  pageChange(newPage: number) {
    this.config.currentPage = newPage;
  }
}
