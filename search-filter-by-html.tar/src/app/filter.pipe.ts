import { Pipe, PipeTransform } from '@angular/core';
import { FilterPipeService } from './filter-pipe.service';


@Pipe({
  name: 'filterSearch'
})
export class FilterPipe implements PipeTransform {
  config: any;
  args;

  constructor(private fs: FilterPipeService) {
    this.fs.getCount.subscribe(x => {
      this.config = {
        totalItems: x
      };
    })
  }
  /*transform(items: any[], searchText: string): any[] {
    
     let filterredName = searchText['filterData'];
    let columnsToFilter = searchText['columns']

    if (!items) return [];
    if (!filterredName) {
      this.fs.getCount.next(items.length);
      return items;
    }
    var xz = {};
    for (let column of columnsToFilter){
      xz = items.filter(it=>it[column].toString().includes(filterredName.toLowerCase()));
    }
    console.log('xz : ', xz)
    //return xz;
  } */
  transform(items: any[], searchText: string): any[] {
    if (!items) return [];
    if (!searchText) {
      this.fs.getCount.next(items.length);
      return items;
  } 

    searchText = searchText.toLowerCase();

    let x = items.filter(it => {
      const name = it.full_name.toString().includes(searchText.toLowerCase())
      const address = it.address.toLowerCase().includes(searchText.toLowerCase())
      const interests = it.interests.toLowerCase().includes(searchText.toLowerCase())
      return (name + address + interests );
  });
  this.fs.getCount.next(x.length);
  return x;
   
  }
}
