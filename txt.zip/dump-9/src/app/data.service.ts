import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { map, catchError, pluck } from 'rxjs/operators'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private url = 'https://reqres.in/api/users';

  constructor(private client: HttpClient) { }

  getSampleData(): any {
    return this.client.get(this.url).pipe(pluck('data'))
  }
}
