export interface State {
  playlist: any[];
}
